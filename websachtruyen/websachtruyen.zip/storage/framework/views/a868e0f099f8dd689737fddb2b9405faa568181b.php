

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Liệt Chapter truyện</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                                <!-- Thêm bootstrap table ở đây -->
                                <table class="table table-striped">
                            <thead>
                                <tr>
                                <th scope="col">#</th>
                                <th scope="col">Tên Chapter</th>
                                <th scope="col">Slug Chapter</th>
                                <th scope="col">Tóm tắt</th>
                                <th scope="col">Thuộc truyện</th>
                                <th scope="col">Kích hoạt</th>
                                <th scope="col">Quản lý</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <th scope="row"><?php echo e($key); ?></th>
                                <td><?php echo e($chap->tentruyen); ?></td>
                                <td><?php echo e($chap->slug_chapter); ?></td>
                                <td><?php echo e($chap->tomtat); ?></td>
                                <td><?php echo e($chap->truyen->tentruyen); ?></td>
                                <td>
                                    <?php if($chap->kichhoat==0): ?>
                                    <span class="text text-success">Kích hoạt</span> 
                                    <?php else: ?>
                                    <span class="text text-danger"> Không kích hoạt</span> 
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('chapter.edit',[$chap->id])); ?>" class="btn btn-success">Sửa</a>
                                    <form action="<?php echo e(route('chapter.destroy',[$chap->id])); ?>" method="POST">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button onclick="return confirm('Bạn có muốn xóa chapter này không?');" class="btn btn-danger"> Xóa</button>

                                    </form>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>       
                        <!-- ////// -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\websachtruyen\resources\views/admincp/chapter/index.blade.php ENDPATH**/ ?>