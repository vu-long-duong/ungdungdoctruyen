            <!-- Sile -->
                <div class="container">
                <h3>SÁCH HAY NÊN ĐỌC</h3>
                <div id="owl-demo">
                                
                    <div class="item"> <img src="<?php echo e(asset('uploads/truyen/Cô-gái-đến-từ-hôm-qua-ảnh-bìa13.jpg')); ?>">
                    <h5>Cô gái đến từ hôm qua</h5>
                    <p><i class=" fas fa-eye"></i>56789</p>
                    <button class="btn btn-danger btn-sm"> Đọc ngay</button>
                    </div>

                    <div class="item"> <img src="<?php echo e(asset('uploads/truyen/Cô-gái-đến-từ-hôm-qua-ảnh-bìa13.jpg')); ?>">
                    <h5>Cô gái đến từ hôm qua</h5>
                    <p><i class=" fas fa-eye"></i>56789</p>
                    <button class="btn btn-danger btn-sm"> Đọc ngay</button>
                    </div>

                    <div class="item"> <img src="<?php echo e(asset('uploads/truyen/Cô-gái-đến-từ-hôm-qua-ảnh-bìa13.jpg')); ?>">
                    <h5>Cô gái đến từ hôm qua</h5>
                    <p><i class=" fas fa-eye"></i>56789</p>
                    <button class="btn btn-danger btn-sm"> Đọc ngay</button>
                    </div>

                    <div class="item"> <img src="<?php echo e(asset('uploads/truyen/Cô-gái-đến-từ-hôm-qua-ảnh-bìa13.jpg')); ?>">
                    <h5>Cô gái đến từ hôm qua</h5>
                    <p><i class=" fas fa-eye"></i>56789</p>
                    <button class="btn btn-danger btn-sm"> Đọc ngay</button>
                    </div>

                    <div class="item"> <img src="<?php echo e(asset('uploads/truyen/Cô-gái-đến-từ-hôm-qua-ảnh-bìa13.jpg')); ?>">
                    <h5>Cô gái đến từ hôm qua</h5>
                    <p><i class=" fas fa-eye"></i>56789</p>
                    <button class="btn btn-danger btn-sm"> Đọc ngay</button>
                    </div>
                    
                    
                    
          
                </div>
                </div>

            <!--End Sile -->
            
            

       <?php /**PATH C:\xampp\htdocs\websachtruyen\resources\views/pages/slide.blade.php ENDPATH**/ ?>